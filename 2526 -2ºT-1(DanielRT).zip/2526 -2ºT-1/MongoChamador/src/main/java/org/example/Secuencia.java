package org.example;

import org.example.model.Personaxe;
import org.example.model.Saga;
import org.example.service.ConexionService;
import org.example.service.SagaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class Secuencia {

    @Autowired
    private final ConexionService conexionService;
    @Autowired
    private final SagaService sagaService;

    public Secuencia(ConexionService conexionService, SagaService sagaService) {
        this.conexionService = conexionService;
        this.sagaService = sagaService;
    }

    public void executar() {

        System.out.println("Iniciando la Secuencia: ");
        System.out.println("Creando la saga y los personajes");

        List<Personaxe> lista_personaxes = new ArrayList<>();
        lista_personaxes.add(new Personaxe("Giorno Giovanna", "Gold Experiencex"));
        lista_personaxes.add(new Personaxe("Bruno Bucciarati", "Sticky Fingers"));
        lista_personaxes.add(new Personaxe("Guido Mista", "Sex Pistols"));

        Saga sagaViento = new Saga();
        sagaViento.setTitulo("Vento Aureo");
        sagaViento.setParte(5);
        sagaViento.setAmbientacion("Italia");
        sagaViento.setAnoinicio(2001);
        sagaViento.setPersonaxes(lista_personaxes);

        System.out.println("Insertandolos a postgres:");
        sagaViento = conexionService.crearSaga(sagaViento);

        Saga sagaLeidoPorId = conexionService.getSagById(2L); // Buscar en postgres por id
        sagaService.saveMongo(sagaLeidoPorId); // insertarla en Mongo

        List<Saga> sagaLeidaPorNombre = conexionService.getSagaByName("Stardust Crusaders");
        Saga saga = sagaLeidaPorNombre.get(0);
        sagaService.saveMongo(saga);

        sagaService.exportarJson();




    }
}
