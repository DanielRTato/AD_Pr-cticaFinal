package org.example.model;

import org.springframework.data.annotation.Id;

public class Personaxe {


    private Long idpersonaxe;
    private String nome;
    private String stand;

    public Personaxe(){}
    public Personaxe( String nome, String stand) {
//        this.idpersonaxe = idpersonaxe;
        this.nome = nome;
        this.stand = stand;
    }

//    public String getId() {
//        return id;
//    }
//
//    public void setId(String id) {
//        this.id = id;
//    }

    public Long getIdpersonaxe() {
        return idpersonaxe;
    }

    public void setIdpersonaxe(Long idpersonaxe) {
        this.idpersonaxe = idpersonaxe;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getStand() {
        return stand;
    }

    public void setStand(String stand) {
        this.stand = stand;
    }
}
