package org.example.controller;


import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping(RestApoioMoral.MAPPING)
public class RestApoioMoral {
    public static final String MAPPING = "";

}